# echo "Setting FastNeuSelAlg v0 in /afs/ihep.ac.cn/users/l/lidj/file"

if test "${CMTROOT}" = ""; then
  CMTROOT=/afs/ihep.ac.cn/soft/dayabay/NuWa-64/external/CMT/v1r20p20080222; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh

tempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then tempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=FastNeuSelAlg -version=v0 -path=/afs/ihep.ac.cn/users/l/lidj/file  -no_cleanup $* >${tempfile}; . ${tempfile}
/bin/rm -f ${tempfile}

